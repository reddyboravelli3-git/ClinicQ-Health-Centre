# ClinicQ Health Centre – Member 2 Database

This folder contains the Member 2 database connection and API route files.

## Included files

- `database/database.js` – opens the existing SQLite database and ensures the doctors, rooms, and bookings tables exist.
- `routes/doctors.js` – doctor API routes.
- `routes/rooms.js` – room API routes.
- `routes/bookings.js` – booking API routes.
- `Server.js` – Express server and route registration.

## Important database note

The original `database/clinicq.db` file is not included in this ZIP because it is a local database file and was excluded from Git. Copy your existing `clinicq.db` into the `database` folder before running this project.

## Setup

1. Open this folder in VS Code.
2. Open the terminal in this folder.
3. Run `npm.cmd install`.
4. Place your existing `clinicq.db` inside the `database` folder.
5. Run `node Server.js`.
6. Open `http://localhost:3000/`.

## API endpoints

- `GET /` – API status
- `GET /doctors` – list doctors
- `GET /doctors/:id` – get one doctor
- `POST /doctors` – add a doctor
- `GET /rooms` – list rooms
- `GET /rooms/:id` – get one room
- `POST /rooms` – add a room
- `GET /bookings` – list bookings with doctor and room names
- `GET /bookings/:id` – get one booking
- `POST /bookings` – add a booking
- `DELETE /bookings/:id` – delete a booking

## Student contribution

Member 2 – Database setup, database connection, and API route implementation.
